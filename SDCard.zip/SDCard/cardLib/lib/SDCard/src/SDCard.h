#ifndef SDCard_h
#define SDCard_h

#include "SparkJson.h"

const uint8_t chipSelect = SS;

class SDCard
{
public:
  int lineCounter;
  uint32_t position;

  //Constructor to initialize Module
  SDCard();

  //initialize SDCard Module
  bool initialize();

  //Write single line to file
  void writeLine(JsonObject& lineObject);

  //Read single line from file
  String readLine();

};

#endif
