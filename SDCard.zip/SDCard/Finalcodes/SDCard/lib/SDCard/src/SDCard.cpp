#include "SDCard.h"
#include "SparkJson.h"
#include "SdFat.h"


SDCard::SDCard()
{
  //Constructor
}

void SDCard::initialize()
{
  // Initialize SdFat or print a detailed error message and halt
  if (!sd.begin(chipSelect, SPI_HALF_SPEED))
  {
    sd.initErrorHalt();
  }

    Serial.print("Current number of lines in file: ");
    Serial.println(lineCounter);

}

void SDCard::writeLine(JsonObject& lineObject)
{
  char str[256];
  lineObject.printTo(str, sizeof(str));
  if(!myFile.open("JsonFile.txt", O_RDWR | O_CREAT | O_AT_END))
  {
    sd.errorHalt("Opening JsonFile.txt for write failed" );
  }
  myFile.seekEnd();
  myFile.println(str);
  myFile.close();
  lineCounter++;
}

String SDCard::readLine()
{
  if(!myFile.open("JsonFile.txt", O_RDWR))
  {
    sd.errorHalt("Opening JsonFile.txt for read failed");
  }
  size_t n;
  char read[256];
  char line[256];
  while(myFile.available())
   {
    char T =  myFile.peek();
    if(T == '*')
    {
      break;
    }
    position = myFile.curPosition();
    n = myFile.fgets(read, sizeof(read));
    for(int i = 0; i<sizeof(read); i++)
    {
      line[i] = read[i];
    }
  }
  if(!myFile.seekSet(position))
  {
    sd.errorHalt("Error in positioning");
  }
  for(int i = 0; i<sizeof(line); i++)
  {
    myFile.write("*");
  }
  lineCounter--;
  myFile.rewind();
  char p = myFile.peek();
  if(p == '*')
  {
    myFile.truncate(0);
  }
  myFile.close();
  return String(line);
}
