#ifndef SDCard_h
#define SDCard_h

#include "SparkJson.h"
#include "SdFat.h"

const uint8_t chipSelect = SS;

class SDCard
{
public:
  int lineCounter = 0;
  uint32_t position;
  SdFat sd;
  File myFile;

  //Constructor to initialize Module
  SDCard();

  //initialize SDCard Module
  void initialize();

  //Write single line to file
  void writeLine(JsonObject& lineObject);

  //Read single line from file
  String readLine();

};

#endif
