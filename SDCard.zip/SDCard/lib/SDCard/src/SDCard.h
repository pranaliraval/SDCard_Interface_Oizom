#ifndef SDCard_h
#define SDCard_h

#include "SparkJson.h"

const uint8_t chipSelect = SS;

class SDCard
{
public:
  //char line[256];
  int lineCounter = 0;

  //Constructor to initialize Module
  SDCard();

  //initialize SDCard Module
  void initialize();

  //Write single line to file
  void writeLine(JsonObject& lineObject);

  //Read single line from file
//  void readLine(char* buff);

};

#endif
